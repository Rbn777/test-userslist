import React from "react";

import ProjectRouter from './Router';

function App() {
  return (
    <>
      <ProjectRouter />
    </>
  );
}

export default App;
